clear all
close all

load('D:\monkeyreverse\dpca\ab_1208_dpca_component_decision_c6a15.mat')  %有问题
componentsToPlot = 6;
Zfull = reshape(Z(:,componentsToPlot)', [length(componentsToPlot) [4 2 2000]]);
data = Zfull;
corrmat_reverse = zeros(3,2);
corrmat_reverse(1,1) = corr( squeeze(data(1, 1, 1, 1:1000)), squeeze(data(1, 4, 1, 1:1000)));
corrmat_reverse(1,2)= corr( squeeze(data(1, 2, 2, 1:1000)), squeeze(data(1, 3, 2, 1:1000)));
load('D:\monkeyreverse\dpca\ab_1201_dpca_component_decision_c9a15_sti_4a6.mat')  
componentsToPlot = 9;
Zfull = reshape(Z(:,componentsToPlot)', [length(componentsToPlot) [4 2 2000]]);
data = Zfull;
corrmat_reverse(2,1) = corr( squeeze(data(1, 1, 1, 1:1000)), squeeze(data(1, 4, 1, 1:1000)));
corrmat_reverse(2,2)= corr( squeeze(data(1, 2, 2, 1:1000)), squeeze(data(1, 3, 2, 1:1000)));
load('D:\monkeyreverse\dpca\ab_1205_dpca_component_decision_c7a10_sti_1a3.mat')  
componentsToPlot = 7;
Zfull = reshape(Z(:,componentsToPlot)', [length(componentsToPlot) [4 2 2000]]);%时间
data = Zfull;
corrmat_reverse(3,1) = corr( squeeze(data(1, 1, 1, 1:1000)), squeeze(data(1, 4, 1, 1:1000)));
corrmat_reverse(3,2)= corr( squeeze(data(1, 2, 2, 1:1000)), squeeze(data(1, 3, 2, 1:1000)));
load('D:\monkeyreverse\dpca\ab_1201_dpca_component_nonreverse_decision_c1a9_sti_2a4.mat')  
componentsToPlot = 1;
Zfull = reshape(Z(:,componentsToPlot)', [length(componentsToPlot) [4 2 1000]]);
data = Zfull;
corrmat = zeros(3,2);
corrmat(1,1) = corr( squeeze(data(1, 1, 1, 1:1000)), squeeze(data(1, 3, 1, 1:1000)));
corrmat(1,2)= corr( squeeze(data(1, 2, 2, 1:1000)), squeeze(data(1, 4, 2, 1:1000)));
load('D:\monkeyreverse\dpca\ab_1205_dpca_component_nonreverse_decision_c2a12_sti_3a6.mat')  
componentsToPlot = 2;
Zfull = reshape(Z(:,componentsToPlot)', [length(componentsToPlot) [4 2 1000]]);
data = Zfull;
corrmat(2,1) = corr( squeeze(data(1, 1, 1, 1:1000)), squeeze(data(1, 3, 1, 1:1000)));
corrmat(2,2)= corr( squeeze(data(1, 2, 2, 1:1000)), squeeze(data(1, 4, 2, 1:1000)));
load('D:\monkeyreverse\dpca\ab_1208_dpca_component_nonreverse_decision_c1a10_sti_3a6.mat')  
componentsToPlot = 1;
Zfull = reshape(Z(:,componentsToPlot)', [length(componentsToPlot) [4 2 1000]]);
data = Zfull;
corrmat(3,1) = corr( squeeze(data(1, 1, 1, 1:1000)), squeeze(data(1, 3, 1, 1:1000)));
corrmat(3,2)= corr( squeeze(data(1, 2, 2, 1:1000)), squeeze(data(1, 4, 2, 1:1000)));

[h,p,ci,stats] = ttest2(corrmat(:),corrmat_reverse(:));

c_map = [0, 0.45, 0.74
        0.85, 0.33, 0.1
        0.93, 0.69, 0.13
        0.49, 0.18, 0.56
        0.46, 0.67, 0.19];
c_map = [176/255, 108/255, 109/255
             56/255, 104/255, 142/255
             175/255, 143/255, 208/255
             213/255, 213/255, 213/255];


fig = figure('Position',[495 186 400 300],...
'Name','response-time figure',...
'NumberTitle','off',...
'Color','w',...
'Menubar','none');
b = bar([mean(corrmat(:)),mean(corrmat_reverse(:))], 0.5,'FaceColor','flat');
b.CData(1,:) = c_map(1,:);
b.CData(2,:) = c_map(2,:);
hold on 
errorbar([mean(corrmat(:)),mean(corrmat_reverse(:))],[std(corrmat(:)),std(corrmat_reverse(:))], 'Color',[72/255 74/255 74/255] , 'Linestyle', 'None', 'LineWidth', 1.5); %?????????????'b'
hold on
ax = gca;
ax.FontName = 'Arial';
line([1 2],[0.90 0.90],'color', 'k','LineWidth',2.0)
text(1.5,0.92,'*','FontSize',18,'FontName','Times New Roman','FontWeight','bold')
xticklabels({'block a & b, rvw-a',' block a & rv-a'})
ylabel('Corr')
box off
set(gca,'linewidth',1.2)
