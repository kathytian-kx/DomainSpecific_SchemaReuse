
clear all
clc

load('D:\monkeyreverse\firingrate\20211118_zz_cl_new_all_firingrate_001.mat')

frpmd_flitered = smoothdata(frpmd(:,:,1:1000),3,'gaussian',50);%50
correct_indx = find(condition_rw == 1);
wrong_indx = find(condition_rw == 2);
frpmd_flitered_correct = frpmd_flitered(correct_indx,:,:);
frpmd_flitered_wrong = frpmd_flitered(wrong_indx,:,:);
conditions_played_correct = conditions_played(correct_indx);
conditions_played_wrong = conditions_played(wrong_indx);
trialNum =[];

N = size(frpmd_flitered,2);
S = 4;
D = 2;
T = size(frpmd(:,:,1:1000),3);
time = (1:T) / 1000;

blockc1 = [];
blockw1 = [];
blockc2 = [];
blockw2 = [];
blockc3 = [];
blockw3 = [];
blockc4 = [];
blockw4 = [];
blockrec1 = [];
blockrew1 = [];
blockrec2 = [];
blockrew2 = [];
for i = 1:1:size(frpmd_flitered,1)
    if conditions_played(1,i) == 1 && condition_rw(i,1)==1&& i < (size(conditions_played,2)/2 +50)
        blockc1 =[blockc1;i];
    end
    if conditions_played(1,i) == 1 && condition_rw(i,1)==2&& i < (size(conditions_played,2)/2 +50)
        blockw1 =[blockw1;i];
    end
    if conditions_played(1,i) == 2 && condition_rw(i,1)==1&& i < (size(conditions_played,2)/2 +50)
        blockc2 =[blockc2;i];
    end
    if conditions_played(1,i) == 2 && condition_rw(i,1)==2&& i < (size(conditions_played,2)/2 +50)
        blockw2 =[blockw2;i];
    end
    if conditions_played(1,i) == 3  && condition_rw(i,1)==1
        blockc3 =[blockc3;i];
    end
    if conditions_played(1,i) == 3  && condition_rw(i,1)==2
        blockw3 =[blockw3;i];
    end
    if conditions_played(1,i) == 4  && condition_rw(i,1)==1
        blockc4 =[blockc4;i];
    end
    if conditions_played(1,i) == 4  && condition_rw(i,1)==2
        blockw4 =[blockw4;i];
    end
    if conditions_played(1,i) == 1 && condition_rw(i,1)==1&& i > (size(conditions_played,2)/2 +50)
        blockrec1 =[blockrec1;i];
    end
    if conditions_played(1,i) == 1 && condition_rw(i,1)==2&& i > (size(conditions_played,2)/2 +50) 
        blockrew1 =[blockrew1;i];
    end
    if conditions_played(1,i) == 2 && condition_rw(i,1)==1&& i > (size(conditions_played,2)/2 +50)
        blockrec2 =[blockrec2;i];
    end
    if conditions_played(1,i) == 2 && condition_rw(i,1)==2&& i > (size(conditions_played,2)/2 +50)
        blockrew2 =[blockrew2;i];
    end
end

block = {blockc1,blockw1;blockw2,blockc2;blockc3,blockw3;blockw4,blockc4;blockrec1,blockrew1;blockrew2,blockrec2};  


maxtrial = 0;
for n = 1:N
    for s = 1:S
        for d = 1:D
            trialNum(n,s,d) = size(block{s, d},1);
            if size(block{s, d},1)>maxtrial
                maxtrial = size(block{s, d},1);
            end
        end
    end
end



firingRates = zeros(N,S,D,size(frpmd(:,:,1:1000),3),maxtrial);
for n = 1:N
    for s = 1:S
        for d = 1:D
            for t = 1:1:trialNum(n,s,d)
                firingRates(n,s,d,:,t) = frpmd_flitered(block{s, d}(t,1),n,:);
            end
        end
    end
end


for n = 1:N
    for s = 1:S
        for d = 1:D
            firingRates(n,s,d,:,trialNum(n,s,d)+1:maxtrial) = nan;
        end
    end
end

% computing PSTHs
firingRatesAverage = nanmean(firingRates, 5);

%% Define parameter grouping


combinedParams = {{1, [1 3]}, {2, [2 3]}, {3}, {[1 2], [1 2 3]}};
margNames = {'Stimulus', 'Decision', 'Condition-independent', 'S/D Interaction'};
margColours = [23 100 171; 187 20 25; 150 150 150; 114 97 171]/256;


timeEvents = time(round(length(time))); 

for n = 1:size(firingRates,1)
    for s = 1:size(firingRates,2)
        for d = 1:size(firingRates,3)
            assert(isempty(find(isnan(firingRates(n,s,d,:,1:trialNum(n,s,d))), 1)), 'Something is wrong!')
        end
    end
end


%% Step 1: PCA of the dataset

X = firingRatesAverage(:,:);
X = bsxfun(@minus, X, nanmean(X,2));

[W,~,~] = svd(X, 'econ');
W = W(:,1:20); 

% minimal plotting
dpca_plot(firingRatesAverage, W, W, @dpca_plot_default);

% computing explained variance
explVar = dpca_explainedVariance(firingRatesAverage, W, W, ...
    'combinedParams', combinedParams);

% a bit more informative plotting
dpca_plot(firingRatesAverage, W, W, @dpca_plot_default, ...
    'explainedVar', explVar, ...
    'time', time,                        ...
    'timeEvents', timeEvents,               ...
    'marginalizationNames', margNames, ...
    'marginalizationColours', margColours);


%% Step 2: PCA in each marginalization separately

dpca_perMarginalization(firingRatesAverage, @dpca_plot_default, ...
   'combinedParams', combinedParams);

%% Step 3: dPCA without regularization and ignoring noise covariance


tic
[W,V,whichMarg] = dpca(firingRatesAverage, 20, ...
    'combinedParams', combinedParams);%20
toc

explVar = dpca_explainedVariance(firingRatesAverage, W, V, ...
    'combinedParams', combinedParams);

dpca_plot(firingRatesAverage, W, V, @dpca_plot_default, ...
    'explainedVar', explVar, ...
    'marginalizationNames', margNames, ...
    'marginalizationColours', margColours, ...
    'whichMarg', whichMarg,                 ...
    'time', time,                        ...
    'timeEvents', timeEvents,               ...
    'timeMarginalization', 3, ...
    'legendSubplot', 16);


%% Step 4: dPCA with regularization

optimalLambda = dpca_optimizeLambda(firingRatesAverage, firingRates, trialNum, ...
    'combinedParams', combinedParams, ...
    'simultaneous', ifSimultaneousRecording, ...
    'numRep', 2, ...  % increase this number to ~10 for better accuracy
    'filename', 'tmp_optimalLambdas.mat');

Cnoise = dpca_getNoiseCovariance(firingRatesAverage, ...
    firingRates, trialNum, 'simultaneous', ifSimultaneousRecording);

[W,V,whichMarg] = dpca(firingRatesAverage, 20, ...%20
    'combinedParams', combinedParams, ...
    'lambda', optimalLambda, ...
    'Cnoise', Cnoise);

explVar = dpca_explainedVariance(firingRatesAverage, W, V, ...
    'combinedParams', combinedParams);

dpca_plot(firingRatesAverage, W, V, @dpca_plot_default, ...
    'explainedVar', explVar, ...
    'marginalizationNames', margNames, ...
    'marginalizationColours', margColours, ...
    'whichMarg', whichMarg,                 ...
    'time', time,                        ...
    'timeEvents', timeEvents,               ...
    'timeMarginalization', 3,           ...
    'legendSubplot', 16);

%% Optional: estimating "signal variance"

explVar = dpca_explainedVariance(firingRatesAverage, W, V, ...
    'combinedParams', combinedParams, ...
    'Cnoise', Cnoise, 'numOfTrials', trialNum);

dpca_plot(firingRatesAverage, W, V, @dpca_plot_default, ...
    'explainedVar', explVar, ...
    'marginalizationNames', margNames, ...
    'marginalizationColours', margColours, ...
    'whichMarg', whichMarg,                 ...
    'time', time,                        ...
    'timeEvents', timeEvents,               ...
    'timeMarginalization', 3,           ...
    'legendSubplot', 16);

%% Optional: decoding

decodingClasses = {[(1:S)' (1:S)'], repmat([1:2], [S 1]), [], [(1:S)' (S+(1:S))']};

accuracy = dpca_classificationAccuracy(firingRatesAverage, firingRates, trialNum, ...
    'lambda', optimalLambda, ...
    'combinedParams', combinedParams, ...
    'decodingClasses', decodingClasses, ...
    'simultaneous', ifSimultaneousRecording, ...
    'numRep', 5, ...        % increase to 100
    'filename', 'tmp_classification_accuracy.mat');

dpca_classificationPlot(accuracy, [], [], [], decodingClasses)

accuracyShuffle = dpca_classificationShuffled(firingRates, trialNum, ...
    'lambda', optimalLambda, ...
    'combinedParams', combinedParams, ...
    'decodingClasses', decodingClasses, ...
    'simultaneous', ifSimultaneousRecording, ...
    'numRep', 5, ...        % increase to 100
    'numShuffles', 20, ...  % increase to 100 (takes a lot of time)
    'filename', 'tmp_classification_accuracy.mat');

dpca_classificationPlot(accuracy, [], accuracyShuffle, [], decodingClasses)

componentsSignif = dpca_signifComponents(accuracy, accuracyShuffle, whichMarg);

dpca_plot(firingRatesAverage, W, V, @dpca_plot_default, ...
    'explainedVar', explVar, ...
    'marginalizationNames', margNames, ...
    'marginalizationColours', margColours, ...
    'whichMarg', whichMarg,                 ...
    'time', time,                        ...
    'timeEvents', timeEvents,               ...
    'timeMarginalization', 3,           ...
    'legendSubplot', 16,                ...
    'componentsSignif', componentsSignif);

%% %% plot ??????
firingRatesAverage = nanmean(firingRates, 5);
X = firingRatesAverage(:,:)';
Xcen = bsxfun(@minus, X, mean(X));
XfullCen = bsxfun(@minus, firingRatesAverage, mean(X)');
N = size(X, 1);
dataDim = size(firingRatesAverage);
Z = Xcen * W;

for componentsToPlot = 1:1:20
  
    fig = figure('Position',[495 186 800 600],...
    'Name','response-time figure',...
    'NumberTitle','off',...
    'Color','w',...
    'Menubar','none');
    Zfull = reshape(Z(:,componentsToPlot)', [length(componentsToPlot) dataDim(2:end)]);
    data = Zfull;
    numOfStimuli = size(data, 2);
    colors = [102/255 0 32/255;36/255 100/255 171/255;177/255 24/255 45/255;71/255 146/255 196/255;212/255 97/255 83/255;145/255 197/255 218/255];
    Ylim = max(max(max(max(abs(data)))));
    thisYlim = Ylim+Ylim/10*1;
    for f = 1:numOfStimuli
        plot([1.4 1.7], [-f*Ylim/10+thisYlim -f*Ylim/10+thisYlim], 'color', colors(f,:), 'LineWidth', 2.5)
        hold on,
        text(1.7, -f*Ylim/10+thisYlim, ['Stimulus ' num2str(f)])
        hold on,
    end
    plot([1.4 1.7], [thisYlim-(f+1)*Ylim/10 thisYlim-(f+1)*Ylim/10], 'k', 'LineWidth', 2.5)
    hold on,
    plot([1.4 1.7], [thisYlim-(f+2)*Ylim/10 thisYlim-(f+2)*Ylim/10],'k', 'LineWidth', 2.5)
    text(1.7, thisYlim-(f+1)*Ylim/10, 'Decision 1')
    text(1.7, thisYlim-(f+2)*Ylim/10, 'Decision 2')

    if whichMarg(componentsToPlot) == 1
        for f=1:numOfStimuli 
            if f == 1|| f==3 || f == 5
                plot(time, squeeze(data(1, f, 1, :)), 'color', colors(f,:), 'LineWidth', 2.5)
                hold on,
            else
                plot(time, squeeze(data(1, f, 2, :)),'-', 'color', colors(f,:), 'LineWidth', 2.5)
                hold on,
            end
        end
        title(['stimulus - component #',num2str(componentsToPlot)])
    elseif whichMarg(componentsToPlot) == 2
        for f=1:numOfStimuli 
            if f == 1|| f==3 || f == 5
                plot(time, squeeze(data(1, f, 1, :)),'-', 'color', colors(f,:), 'LineWidth', 2.5)
                hold on,
            else
                plot(time, squeeze(data(1, f, 2, :)),'-', 'color', colors(f,:), 'LineWidth', 2.5)
                hold on,
            end
        end
        title(['decision - component #',num2str(componentsToPlot)])
    elseif whichMarg(componentsToPlot) == 3
        for f=1:numOfStimuli 
            if f == 1|| f==3 || f == 5
                plot(time, squeeze(data(1, f, 1, :)),'-', 'color', colors(f,:), 'LineWidth', 2.5)
                hold on,
            else
                plot(time, squeeze(data(1, f, 2, :)),'-', 'color', colors(f,:), 'LineWidth', 2.5)
                hold on,
            end
        end
        title(['Conditionindependent - component #',num2str(componentsToPlot)])
    elseif whichMarg(componentsToPlot) == 4
        for f=1:numOfStimuli 
            if f == 1|| f==3 || f == 5
                plot(time, squeeze(data(1, f, 1, :)),'-', 'color', colors(f,:), 'LineWidth', 2.5)
                hold on,
            else
                plot(time, squeeze(data(1, f, 2, :)),'-', 'color', colors(f,:), 'LineWidth', 2.5)
                hold on,
            end
        end
        title(['S/D interaction - component #',num2str(componentsToPlot)])
    end
    xlabel('Time (s)')
    ylabel('Normalized firing rate (Hz)')
    axis([time(1) time(end) [-thisYlim thisYlim]])

    box off

end
