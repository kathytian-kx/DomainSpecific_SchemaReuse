 clear all
close all

trial_indx_zz = zeros(3,3); 
load('D:\monkeyreverse\firingrate\20211118_zz_cl_new_all_firingrate_001.mat')

blocka_indx = [];
blockb_indx = [];
blockrea_indx = [];
for i = 1:1:size(condition_rw,1)-1
if (conditions_played(:,i)== 1 || conditions_played(:,i)== 2) && (conditions_played(:,i+1)==3 || conditions_played(:,i+1)==4)
blocka_indx = i;
elseif (conditions_played(:,i)== 3 || conditions_played(:,i)== 4) && (conditions_played(:,i+1)==1 || conditions_played(:,i+1)==2)
blockb_indx = i;
end
end
blockrea_indx = size(condition_rw,1);
timewin = 19;
slide = 1;
acc_b = [];
acc_rea = [];
for i = blocka_indx+1:slide:blockb_indx-timewin
acc_b = [acc_b;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
if size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)>0.9
trial_indx_zz(1,1) = i+19-blocka_indx+1;
break
end
end
for i = blockb_indx+1:slide:blockrea_indx-timewin
acc_rea = [acc_rea;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
if size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)>0.9
trial_indx_zz(1,2) = i+19-blockb_indx+1;
break
end
end
load('D:\monkeyreverse\firingrate\20211118_zz_reverse_all_firingrate_001.mat')
acc_reverse = [];
for i = 1:slide:size(condition_rw,1)-timewin
acc_reverse = [acc_reverse;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
if size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)>0.9
trial_indx_zz(1,3) = i+19;
break
end
end
load('D:\monkeyreverse\firingrate\20211124_zz_cl_new_all_firingrate_001.mat')
%??????block
blocka_indx = [];
blockb_indx = [];
blockrea_indx = [];
for i = 1:1:size(condition_rw,1)-1
if (conditions_played(:,i)== 1 || conditions_played(:,i)== 2) && (conditions_played(:,i+1)==3 || conditions_played(:,i+1)==4)
blocka_indx = i;
elseif (conditions_played(:,i)== 3 || conditions_played(:,i)== 4) && (conditions_played(:,i+1)==1 || conditions_played(:,i+1)==2)
blockb_indx = i;
end
end
blockrea_indx = size(condition_rw,1);
timewin = 19;
slide = 1;
acc_b = [];
acc_rea = [];
for i = blocka_indx+1:slide:blockb_indx-timewin
acc_b = [acc_b;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
if size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)>0.9
trial_indx_zz(2,1) = i+19-blocka_indx+1;
break
end
end
for i = blockb_indx+1:slide:blockrea_indx-timewin
acc_rea = [acc_rea;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
if size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)>0.9
trial_indx_zz(2,2) = i+19-blockb_indx+1;
break
end
end
load('D:\monkeyreverse\firingrate\20211124_zz_reverse_all_firingrate_001.mat')
acc_reverse = [];
for i = 1:slide:size(condition_rw,1)-timewin
acc_reverse = [acc_reverse;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
if size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)>0.9
trial_indx_zz(2,3) = i+19;
break
end
end
load('D:\monkeyreverse\firingrate\20211125_zz_cl_new_all_firingrate_001.mat')
%??????block
blocka_indx = [];
blockb_indx = [];
blockrea_indx = [];
for i = 1:1:size(condition_rw,1)-1
if (conditions_played(:,i)== 1 || conditions_played(:,i)== 2) && (conditions_played(:,i+1)==3 || conditions_played(:,i+1)==4)
blocka_indx = i;
elseif (conditions_played(:,i)== 3 || conditions_played(:,i)== 4) && (conditions_played(:,i+1)==1 || conditions_played(:,i+1)==2)
blockb_indx = i;
end
end
blockrea_indx = size(condition_rw,1);
timewin = 19;
slide = 1;
acc_b = [];
acc_rea = [];
for i = blocka_indx+1:slide:blockb_indx-timewin
acc_b = [acc_b;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
if size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)>0.9
trial_indx_zz(3,1) = i+19-blocka_indx+1;
break
end
end
for i = blockb_indx+1:slide:blockrea_indx-timewin
acc_rea = [acc_rea;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
if size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)>0.9
trial_indx_zz(3,2) = i+19-blockb_indx+1;
break
end
end
load('D:\monkeyreverse\firingrate\20211125_zz_reverse_all_firingrate_001.mat')
acc_reverse = [];
for i = 1:slide:size(condition_rw,1)-timewin
acc_reverse = [acc_reverse;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
if size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)>0.9
trial_indx_zz(3,3) = i+19;
break
end
end
load('D:\monkeyreverse\dpca\zz_1118_dpca_component_all_decision_c4_sti_2.mat')
componentsToPlot = 4;
Zfull = reshape(Z(:,componentsToPlot)', [length(componentsToPlot) [8 2 2000]]);
data = Zfull;
corrmat_1118 = zeros(3,2);% 1-A&B 2-A&re-A 3-A&reverse-A
corrmat_1118(1,1) = corr( squeeze(data(1, 1, 1, 1:1000)), squeeze(data(1, 3, 1, 1:1000)));
corrmat_1118(1,2)= corr( squeeze(data(1, 2, 2, 1:1000)), squeeze(data(1, 4, 2, 1:1000)));
corrmat_1118(2,1) = corr( squeeze(data(1, 1, 1, 1:1000)), squeeze(data(1, 5, 1, 1:1000)));
corrmat_1118(2,2)= corr( squeeze(data(1, 2, 2, 1:1000)), squeeze(data(1, 6, 2, 1:1000)));
corrmat_1118(3,1) = corr( squeeze(data(1, 1, 1, 1:1000)), squeeze(data(1, 8, 1, 1:1000)));
corrmat_1118(3,2)= corr( squeeze(data(1, 2, 2, 1:1000)), squeeze(data(1, 7, 2, 1:1000)));
load('D:\monkeyreverse\dpca\zz_1124_dpca_component_all_decision_c2_sti_3a7.mat')
componentsToPlot = 2;
corrmat_1124 = zeros(3,2);
Zfull = reshape(Z(:,componentsToPlot)', [length(componentsToPlot) [8 2 2000]]);
data = Zfull;
corrmat_1124(1,1) = corr( squeeze(data(1, 1, 1, 1:1000)), squeeze(data(1, 3, 1, 1:1000)));
corrmat_1124(1,2)= corr( squeeze(data(1, 2, 2, 1:1000)), squeeze(data(1, 4, 2, 1:1000)));
corrmat_1124(2,1) = corr( squeeze(data(1, 1, 1, 1:1000)), squeeze(data(1, 5, 1, 1:1000)));
corrmat_1124(2,2)= corr( squeeze(data(1, 2, 2, 1:1000)), squeeze(data(1, 6, 2, 1:1000)));
corrmat_1124(3,1) = corr( squeeze(data(1, 1, 1, 1:1000)), squeeze(data(1, 8, 1, 1:1000)));
corrmat_1124(3,2)= corr( squeeze(data(1, 2, 2, 1:1000)), squeeze(data(1, 7, 2, 1:1000)));
load('D:\monkeyreverse\dpca\zz_1125_dpca_component_all_decision_c6_sti_2a5.mat')
componentsToPlot = 6;
corrmat_1125 = zeros(3,2);
Zfull = reshape(Z(:,componentsToPlot)', [length(componentsToPlot) [8 2 2000]]);
data = Zfull;
corrmat_1125(1,1) = corr( squeeze(data(1, 1, 1, 1:1000)), squeeze(data(1, 3, 1, 1:1000)));
corrmat_1125(1,2)= corr( squeeze(data(1, 2, 2, 1:1000)), squeeze(data(1, 4, 2, 1:1000)));
corrmat_1125(2,1) = corr( squeeze(data(1, 1, 1, 1:1000)), squeeze(data(1, 5, 1, 1:1000)));
corrmat_1125(2,2)= corr( squeeze(data(1, 2, 2, 1:1000)), squeeze(data(1, 6, 2, 1:1000)));
corrmat_1125(3,1) = corr( squeeze(data(1, 1, 1, 1:1000)), squeeze(data(1, 8, 1, 1:1000)));
corrmat_1125(3,2)= corr( squeeze(data(1, 2, 2, 1:1000)), squeeze(data(1, 7, 2, 1:1000)));
behavior_zz = mean(trial_indx_zz,1);
behavior_zz_mean = mean(trial_indx_zz,1);
behavior_zz_std = std(trial_indx_zz,1);
corrmar_zz = zeros(3,3);
corrmat_zz(1,:) = mean(corrmat_1118,2);
corrmat_zz(2,:) = mean(corrmat_1124,2);
corrmat_zz(3,:) = mean(corrmat_1125,2);
corrmat_zz_mean = mean(corrmat_zz,1);
corrmat_zz_mean = mean(corrmat_zz,1);
corrmat_zz_std = std(corrmat_zz,1);
% zz
c_map = [0, 0.45, 0.74
        0.85, 0.33, 0.1
        0.93, 0.69, 0.13
        0.49, 0.18, 0.56
        0.46, 0.67, 0.19];
c_map = [176/255, 108/255, 109/255
             56/255, 104/255, 142/255
             175/255, 143/255, 208/255
             213/255, 213/255, 213/255];
    

X = corr(trial_indx_zz(:),corrmat_zz(:));

fig = figure('Position',[495 186 400 300],...
'Name','response-time figure',...
'NumberTitle','off',...
'Color','w',...
'Menubar','none');
hold on
for i = 1:1:3
errorbar(behavior_zz_mean(i),corrmat_zz_mean(i),corrmat_zz_std(i),corrmat_zz_std(i),behavior_zz_std(i),behavior_zz_std(i),'o','linewidth',2,'color',c_map(i,:),'LineStyle','-')
hold on
end
for i =1:1:3
scatter(trial_indx_zz(:,i),corrmat_zz(:,i),[],c_map(i,:),'filled','linewidth',2)
hold on
end
plot([100 110], [0.85 0.85], 'color', c_map(1,:), 'LineWidth', 2.5)
hold on,
text(112, 0.85,'block a & b','FontSize',8)
hold on,
plot([100 110], [0.80 0.80], 'color', c_map(2,:), 'LineWidth', 2.5)
hold on,
text(112, 0.80, 'block a & rvw-a','FontSize',8)
hold on,
plot([100 110], [0.75 0.75], 'color', c_map(3,:), 'LineWidth', 2.5)
hold on,
text(112, 0.75, 'block a & rv-a','FontSize',8)
hold on,
trial_indx = [squeeze(trial_indx_zz(:))];
corrmat = [squeeze(corrmat_zz(:))];
p = polyfit(trial_indx,corrmat,1)
x_fit = linspace(min(trial_indx),max(trial_indx),100)
y_fit = polyval(p,x_fit)
hold on
plot(x_fit,y_fit,'k','LineWidth', 3)
ax = gca;
ax.FontName = 'Arial';
xlabel('Trial')
ylabel('Corr')
Li = LinearModel.fit(trial_indx,corrmat);
R2 = Li.Rsquared.Ordinary;
P = Li.ModelFitVsNullModel.Pvalue;  
annotation('textbox',[.18 .62 .3 .3],'String',{'P = 0.0406','R^{2} = 0.4731'},'FitBoxToText','on','FontSize',8);
box off
set(gca,'linewidth',1.2)