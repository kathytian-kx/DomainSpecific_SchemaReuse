This repository contains scripts for analyzing behavioral and neural data in the paper "Domain-specific Schema Reuse Supports Flexible Learning to Learn in Primate Brain". Below is a detailed description of each folder, its functionality, and the required software environment and dependencies.

1. behavior/
This folder contains MATLAB R2023b scripts for processing and analyzing behavioral data collected from macaques during experimental tasks.

Scripts and Their Functions:
- behavior_analysis_one_monkey.m: Behavioral analysis of a single monkey, drawing learning curves for different tasks and bar charts of the number of trials required  for the monkey to achieve 90% accuracy in learning the tasks.
- behavior_analysis_two_monkey.m: Statistical analysis of two monkeys shows the number of trials required for the monkey to achieve an accuracy rate of 90% in learning tasks A, B, and review, as well as flipping tasks.

Environment and Dependencies:
MATLAB Version: R2023b

2. classification/
This folder includes scripts that perform dimensionality reduction using LFADS (Chethan Pandarinath et al., 2018) on spike data. The reduced data is then classified into visual stimuli and motor decisions using a Convolutional Neural Network (CNN).

Scripts and Their Functions:
- runscript_lfads.m: Using LFADS to reduce the spike data.
- classifydecision.py: Classifies decisions using CNN on LFADS-reduced spike data and test the model performance on Review task.
- classifystimulus.py: Classifies visual stimuli using CNN on LFADS-reduced spike data and test the model performance on Review task.

Environment and Dependencies:
MATLAB Version: R2023b
Python Version: 2.7
Packages Required:
sklearn, NumPy, Pytorch, Matplotlib, H5py
Additional Tools:
LFADS model for spike data dimensionality reduction. (refer to the LFADS repository for setup and usage: https://lfads.github.io/lfads-run-manager)

3. dpca/
This folder contains scripts developed in MATLAB R2023b for applying dPCA to spike data.

Scripts and Their Functions:
- dpca_one_monkey: Reduce neural data into decision and stimuli dimensions using dPCA.
- correlation_one_monkey.m: Computes manifold similarity across tasks within the decision subspace.
- linear_relationship_one_monkey.m: Calculate the linear relationship between the similarity of decision subspace manifolds and the learning speed.

Environment and Dependencies:
- MATLAB Version: R2023b
Packages Required:
dPCA toolbox (available at: http://github.com/machenslab/dPCA)

4. orthogonal/
This folder includes scripts for analyzing angular relationships between stimulus and decision subspaces.

Scripts and Their Functions:
- orth_statics.m and subspace_angle.m: Quantifies subspace angle relationships between stimulus and decision subspaces and shuffle results.
- bar_plot_a.m: Visualizes subspace angle statistics using bar plots and Compares original and shuffled data for significance testing.
- scatter_distribution.ipynb: Using scatter plots to show trial distributions for different stimuli and decisions. 
- traj_intensity.ipynb: Visualizes neural activity over time in orthogonal conditions using line and KDE plots.

Environment and Dependencies:
- MATLAB Version: R2023b
- Python Version:3.8
Toolboxes Required:
os, pickle, NumPy, scipy, Matplotlib, seaborn, pandas

5. Contact
For questions or issues related to the code, please contact the author of this repository.