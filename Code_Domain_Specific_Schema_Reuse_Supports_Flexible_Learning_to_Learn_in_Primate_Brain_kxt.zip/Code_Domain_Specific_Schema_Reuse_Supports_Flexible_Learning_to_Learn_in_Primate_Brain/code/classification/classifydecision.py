"""CNN"""

import h5py
import random
import numpy as np
from scipy.io import loadmat
import torch
from torch.autograd import Variable 
import torchvision
import torch.nn as nn
import torch.utils.data as nndata
import seaborn as sns
from sklearn import preprocessing
from sklearn.metrics import confusion_matrix
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
torch.manual_seed(1) 

#Hyper Parameters
EPOCH = 2000
BATCH_SIZE = 5#20
LR = 0.001#0.001



f = h5py.File(
    '/n19dat01/kxtian/lfads_run_manager/zz_example/runs/exampleSingleRun/param_xmT7ww/single_20211125_zz_cl_new_pmd_all_001align20/lfadsOutput/model_runs_20211125_zz_cl_new_pmd_all_001align20.h5_train_posterior_sample_and_average',
    'r') # 6 dim latent variables
factors = f['factors']
factors = factors[0:125:1, 0:100:1, :]#block a&b
factors_reshape = factors.reshape(125,100*6)
min_max_scaler = preprocessing.MinMaxScaler(feature_range=(0, 1))

factors = min_max_scaler.fit_transform(factors_reshape)
factors = factors.reshape(125,100,6)

factors = torch.tensor(factors)
factors = torch.unsqueeze(factors,1)
# label
filename = '/n19dat01/kxtian/lfads_run_manager/zz_example/runs/exampleSingleRun/param_xmT7ww/single_20211125_zz_cl_new_pmd_all_001align20/lfadsInput/inputInfo_20211125_zz_cl_new_pmd_all_001align20.mat'
runinput = loadmat(filename)
trainInds = runinput['trainInds']
conditionId = runinput['conditionId']
trainInds = trainInds[:,0:125:1]

trainlabel = []
testlabel = []

for i in range(np.size(trainInds)):
    if (conditionId[trainInds[:, i]-1]-1 == 2 or conditionId[trainInds[:, i]-1]-1 == 0):
        trainlabel = np.append(trainlabel, 0 )
    if (conditionId[trainInds[:, i]-1]-1 == 3 or conditionId[trainInds[:, i]-1]-1 == 1):
        trainlabel = np.append(trainlabel, 1 )


trainlabel = torch.tensor(trainlabel)



class GetLoader(torch.utils.data.Dataset):
    def __init__(self, data_root, data_label):
        self.data = data_root
        self.label = data_label

    def __getitem__(self, index):
        data = self.data[index]
        labels = self.label[index]
        return data, labels

    def __len__(self):
        return len(self.data)


k_acc = []
k_fold = 125
for k in range(k_fold):
    indextrain = []
    indextest = []
    factorstrain = []
    train_label = []
    factorstest = []
    testlabel = []

    L1 = random.sample(range(np.size(factors,0)), np.size(factors,0))
    sli = int(np.size(factors,0)/k_fold)
    indextest = L1[sli*k:sli*(k+1)]
    factorstest = factors[indextest]
    testlabel = trainlabel[indextest]

    for i in range(np.size(factors,0)):
        if i not in indextest:
            indextrain.append(i)
    indextrain = np.array(indextrain)
    factorstrain = factors[indextrain]
    train_label = trainlabel[indextrain]


    train_data = GetLoader(factorstrain, train_label)
    test_data = GetLoader(factorstest, testlabel)

    train_loader = nndata.DataLoader(dataset=train_data, batch_size=BATCH_SIZE, shuffle=True)
    test_loader = nndata.DataLoader(dataset=test_data, batch_size=BATCH_SIZE, shuffle=True)

    for epoch in range(2):
        for i, data in enumerate(train_loader):
            inputs, labels = data
            inputs, labels = Variable(inputs), Variable(labels)
            print("epoch：", epoch, "的第" , i, "个inputs", inputs.data.size(), "labels", labels.data.size())



    test_x = factorstest
    test_y = testlabel

    class CNN(nn.Module):
        def __init__(self):
            super(CNN, self).__init__()
            self.conv1 = nn.Sequential( 
                nn.Conv2d(in_channels=1, 
                          out_channels=8, 
                         kernel_size=3, 
                         stride=1, 
                         padding=1 
                         ), 

                nn.ReLU(), 
                nn.MaxPool2d(kernel_size=2) 

            )
            self.conv2 = nn.Sequential(nn.Conv2d(8, 8, 3, 1, 1), 
                                      nn.ReLU(),
                                      nn.MaxPool2d(2))

            self.dropout = nn.Dropout(p = 0.5) 
            self.out = nn.Linear(8*25*1,2)  

        def forward(self, x):
            x = x.to(torch.float32)
            x = self.conv1(x)
            x = self.conv2(x)
            x = x.view(x.size(0), -1) 
            x = self.dropout(x)
            output = self.out(x)
            return output

    cnn = CNN()
    print(cnn)

    #optimizer
    optimizer = torch.optim.Adam(cnn.parameters(), lr=LR,weight_decay=0.001)#

    #loss_fun
    loss_func = nn.CrossEntropyLoss()
    loss_count = []
    accuracy_list = []

    #training loop
    for epoch in range(EPOCH):
        for i, (x, y) in enumerate(train_loader):
            batch_x = Variable(x)
            batch_y = Variable(y)
            output = cnn(batch_x)
            loss = loss_func(output, batch_y.long())
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            if i%20 == 0 :
                loss_count.append(loss)
                print('{}:\t'.format(i), loss.item())
                torch.save(cnn, r'zz_cnn100msclassify2_dat25_align20_blocka.pt')
                torch.save(cnn.state_dict(), r'zz_cnnclassify2_100ms_dat25_align20_blocka.pt')

            if i % 100 == 0:
                test_x = Variable(factorstrain)
                test_y = Variable(train_label)
                out = cnn(test_x)
                accuracy = torch.max(out, 1)[1].numpy() == test_y.numpy()
                accuracy_list.append(accuracy.mean())
                print('accuracy:\t', accuracy.mean())
                break



    accuracy_sum = []
    testy = []
    outy = []
    test_x = Variable(factorstest)
    test_y = Variable(testlabel)
    print('test_y:\t', test_y)
    out = cnn(test_x)
    print('out:\t', out)
    print('test_out:\t',torch.max(out,1)[1])
    outy.append(torch.max(out,1)[1].numpy())
    accuracy = torch.max(out,1)[1].numpy() == test_y.numpy()
    accuracy_sum.append(accuracy.mean())
    print('accuracy:\t',accuracy.mean())

    print('总准确率：\t',sum(accuracy_sum)/len(accuracy_sum))
    print('总准确率：\t',sum(accuracy_sum)/len(accuracy_sum))
    k_acc.append(accuracy_sum)

    test_output =cnn(test_x[:]) 
    pred_y = torch.max(test_output,1)[1].data.numpy().squeeze()
    print(pred_y, 'prediction number')
    print(test_y[:])

    y_pred = [] 
    y_true = [] 
    y_pred = torch.max(out,1)[1].numpy()
    y_true = test_y.numpy()
    C = confusion_matrix(y_true, y_pred, labels=[0,1,2,3,4,5]) 

    

print(k_acc)
print(np.mean(k_acc))
print(np.var(k_acc))



# test in task review
f = h5py.File(
    '/n19dat01/kxtian/lfads_run_manager/zz_example/runs/exampleSingleRun/param_xmT7ww/single_20211125_zz_cl_new_pmd_all_001align20/lfadsOutput/model_runs_20211125_zz_cl_new_pmd_all_001align20.h5_train_posterior_sample_and_average',
    'r')
factors = f['factors']
factors_c = factors[167:207:1, 0:100:1, :] # task review
factors_reshape_c = factors_c.reshape(40,100*6)
min_max_scaler = preprocessing.MinMaxScaler(feature_range=(0, 1))
factors_c = min_max_scaler.fit_transform(factors_reshape_c)
factors_c = factors_c.reshape(40,100,6)

factors_c = torch.tensor(factors_c)
factors_c = torch.unsqueeze(factors_c,1)
# read label
filename = '/n19dat01/kxtian/lfads_run_manager/zz_example/runs/exampleSingleRun/param_xmT7ww/single_20211125_zz_cl_new_pmd_all_001align20/lfadsInput/inputInfo_20211125_zz_cl_new_pmd_all_001align20.mat'
runinput = loadmat(filename)
trainInds = runinput['trainInds']
conditionId = runinput['conditionId']
trainInds = trainInds[:,167:207:1]

label_c = []

for i in range(np.size(trainInds)):
    if (conditionId[trainInds[:, i]-1]-1 == 2 or conditionId[trainInds[:, i]-1]-1 == 0):
        label_c = np.append(label_c, 0 )
    if (conditionId[trainInds[:, i]-1]-1 == 3 or conditionId[trainInds[:, i]-1]-1 == 1):
        label_c = np.append(label_c, 1 )

label_c = torch.tensor(label_c)

cnn = torch.load('zz_cnn100msclassify2_dat25_align20_blocka.pt')
cnn.load_state_dict(torch.load('zz_cnnclassify2_100ms_dat25_align20_blocka.pt'))


accuracy_sum = []
accuracy = []
testy = []
outy = []
c_x = Variable(factors_c)
c_y = Variable(label_c)
print('test_y:\t', c_y)
out = cnn(c_x)
print('out:\t', out)
print('test_out:\t', torch.max(out, 1)[1])
outy.append(torch.max(out, 1)[1].numpy())
accuracy = torch.max(out, 1)[1].numpy() == c_y.numpy()
accuracy_sum.append(accuracy.mean())
print('accuracy:\t', accuracy.mean())
