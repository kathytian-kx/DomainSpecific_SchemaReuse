addpath('/n19dat01/kxtian/lfads_run_manager/lfads-run-manager/src')%添加路径
dataPath = '/n19dat01/kxtian/lfads_run_manager/zz_example/zz_spikes';

dc = XWExperiment.DatasetCollection(dataPath);
dc.name = 'zz_example';

dataPath = '/n19dat01/kxtian/lfads_run_manager/zz_example/zz_spikes';

XWExperiment.Dataset(dc, 'zz_20211125_cl_new_oldsorting_all_spike_pmd_2s.mat');


dc.loadInfo();
dc.getDatasetInfoTable  
runRoot = '/n19dat01/kxtian/lfads_run_manager/zz_example/runs';
rc = XWExperiment.RunCollection(runRoot, 'exampleSingleRun', dc);
rc.version = 20230902;
par = XWExperiment.RunParams;
par.name = 'first_attempt'; 
% par.useAlignmentMatrix = true; % use alignment matrices initial guess for multisession stitching

par.spikeBinMs = 10; 
par.c_co_dim = 0; 
par.c_ic_dim = 64;
par.c_batch_size = 5;
par.c_factors_dim = 6; 
par.c_max_grad_norm = 100;
par.c_cell_clip_value = 3;
par.c_gen_dim = 64;
par.c_ic_enc_dim = 64;
par.c_learning_rate_stop = 1e-4; 
par.c_learning_rate_init = 0.001;
par.c_output_dist='poisson';
par.trainToTestRatio=4;

rc.addParams(par);
ds_index = 1;
runSpecName = dc.datasets(ds_index).getSingleRunName();
runSpec = XWExperiment.RunSpec(runSpecName, dc, ds_index);
rc.addRunSpec(runSpec);
rc.prepareForLFADS();
rc.runs(1).writeShellScriptLFADSTrain('cuda_visible_devices', 0, 'display', 0);
rc.runs(1).writeShellScriptLFADSPosteriorMeanSample('cuda_visible_devices', 0);
rc.runs(1).writeShellScriptLFADSWriteModelParams('cuda_visible_devices', 0);
rc.writeTensorboardShellScript();

rc.addParams(par);
runSpecName = 'all';
runSpec = XWExperiment.RunSpec(runSpecName, dc, 1:dc.nDatasets);
rc.addRunSpec(runSpec);
for iR = 1:dc.nDatasets
    runSpecName = dc.datasets(iR).getSingleRunName(); % 'single_dataset###'
    runSpec = XWExperiment.RunSpec(runSpecName, dc, iR);
    rc.addRunSpec(runSpec);
end
run = rc.findRuns('all', 1);
run.doMultisessionAlignment();
tool = run.multisessionAlignmentTool;
nFactorsPlot = 3;
conditionsToPlot = [1 2];
tool.plotAlignmentReconstruction(nFactorsPlot, conditionsToPlot);
tool.alignmentMatrices 
rc.prepareForLFADS();

rc.writeShellScriptRunQueue('display', 0, 'virtualenv', 'kxtian_py2');
