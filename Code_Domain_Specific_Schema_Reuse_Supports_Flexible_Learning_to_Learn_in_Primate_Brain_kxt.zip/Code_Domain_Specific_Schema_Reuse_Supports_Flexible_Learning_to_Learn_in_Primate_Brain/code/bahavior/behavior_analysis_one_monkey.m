% behavior analysis for one monkey
clc
clear
close all
date = '20211208';
subject = 'ab';
experiment = 'cl\_new';
area = 'all';
n = '001';
load('D:\monkeyreverse\firingrate\20211201_ab_cl_new_all_firingrate_001.mat')

blocka_indx = [];
blockb_indx = [];
blockrea_indx = [];
for i = 1:1:size(condition_rw,1)-1
    if (conditions_played(:,i)== 1 || conditions_played(:,i)== 2) && (conditions_played(:,i+1)==3 || conditions_played(:,i+1)==4)
        blocka_indx = i;
    elseif (conditions_played(:,i)== 3 || conditions_played(:,i)== 4) && (conditions_played(:,i+1)==1 || conditions_played(:,i+1)==2)
        blockb_indx = i;
    end
end
blockrea_indx = size(condition_rw,1);

for i = 1:1:blocka_indx
    if condition_rw(i,:)==1
        hold on 
        plot([i,i],[0,1],'k')
    end
end
hold on
for i = blocka_indx+1:1:blockb_indx
    if condition_rw(i,:)==1
        hold on 
        plot([i-blocka_indx,i-blocka_indx],[3,4],'r')
    end
end
hold on
for i = blockb_indx+1:1:blockrea_indx
    if condition_rw(i,:)==1
        hold on 
        plot([i-blockb_indx,i-blockb_indx],[6,7],'g')
    end
end

timewin = 19;
slide = 1;
acc_a = [];
acc_b = [];
acc_rea = [];
for i = 1:slide:blocka_indx-timewin
    acc_a = [acc_a;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
for i = blocka_indx+1:slide:blockb_indx-timewin
    acc_b = [acc_b;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
for i = blockb_indx+1:slide:blockrea_indx-timewin
    acc_rea = [acc_rea;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end

load('D:\monkeyreverse\firingrate\20211205_ab_cl_new_all_firingrate_001.mat')
blocka_indx_day2 = [];
blockb_indx_day2 = [];
blockrea_indx_day2 = [];
for i = 1:1:size(condition_rw,1)-1
    if (conditions_played(:,i)== 1 || conditions_played(:,i)== 2) && (conditions_played(:,i+1)==3 || conditions_played(:,i+1)==4)
        blocka_indx_day2 = i;
    elseif (conditions_played(:,i)== 3 || conditions_played(:,i)== 4) && (conditions_played(:,i+1)==1 || conditions_played(:,i+1)==2)
        blockb_indx_day2 = i;
    end
end
blockrea_indx_day2 = size(condition_rw,1);

hold on
for i = 1:1:blocka_indx_day2
    if condition_rw(i,:)==1
        hold on 
        plot([i,i],[1,2],'k')
    end
end
hold on
for i = blocka_indx_day2+1:1:blockb_indx_day2
    if condition_rw(i,:)==1
        hold on 
        plot([i-blocka_indx_day2,i-blocka_indx_day2],[4,5],'r')
    end
end
hold on
for i = blockb_indx_day2+1:1:blockrea_indx_day2
    if condition_rw(i,:)==1
        hold on 
        plot([i-blockb_indx_day2,i-blockb_indx_day2],[7,8],'g')
    end
end

slide = 1;
acc_a_day2 = [];
acc_b_day2 = [];
acc_rea_day2 = [];
for i = 1:slide:blocka_indx_day2-timewin
    acc_a_day2 = [acc_a_day2;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
for i = blocka_indx_day2+1:slide:blockb_indx_day2-timewin
    acc_b_day2 = [acc_b_day2;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
for i = blockb_indx_day2+1:slide:blockrea_indx_day2-timewin
    acc_rea_day2 = [acc_rea_day2;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end

load('D:\monkeyreverse\firingrate\20211208_ab_cl_new_all_firingrate_001.mat')
blocka_indx_day3 = [];
blockb_indx_day3 = [];
blockrea_indx_day3 = [];
for i = 1:1:size(condition_rw,1)-1
    if (conditions_played(:,i)== 1 || conditions_played(:,i)== 2) && (conditions_played(:,i+1)==3 || conditions_played(:,i+1)==4)
        blocka_indx_day3 = i;
    elseif (conditions_played(:,i)== 3 || conditions_played(:,i)== 4) && (conditions_played(:,i+1)==1 || conditions_played(:,i+1)==2)
        blockb_indx_day3 = i;
    end
end
blockrea_indx_day3 = size(condition_rw,1);

hold on
for i = 1:1:blocka_indx_day3
    if condition_rw(i,:)==1
        hold on 
        plot([i,i],[2,3],'k')
    end
end
hold on
for i = blocka_indx_day3+1:1:blockb_indx_day3
    if condition_rw(i,:)==1
        hold on 
        plot([i-blocka_indx_day3,i-blocka_indx_day3],[5,6],'r')
    end
end
hold on
for i = blockb_indx_day3+1:1:blockrea_indx_day3
    if condition_rw(i,:)==1
        hold on 
        plot([i-blockb_indx_day3,i-blockb_indx_day3],[8,9],'g')
    end
end


slide = 1;
acc_a_day3 = [];
acc_b_day3 = [];
acc_rea_day3 = [];
for i = 1:slide:blocka_indx_day3-timewin
    acc_a_day3 = [acc_a_day3;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
for i = blocka_indx_day3+1:slide:blockb_indx_day3-timewin
    acc_b_day3 = [acc_b_day3;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
for i = blockb_indx_day3+1:slide:blockrea_indx_day3-timewin
    acc_rea_day3 = [acc_rea_day3;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end

load('D:\monkeyreverse\firingrate\20211201_ab_reverse_all_firingrate_001.mat')
acc_reverse = [];
for i = 1:slide:size(condition_rw,1)-timewin
    acc_reverse = [acc_reverse;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
load('D:\monkeyreverse\firingrate\20211205_ab_reverse_all_firingrate_001.mat')
acc_reverse_day2 = [];
for i = 1:slide:size(condition_rw,1)-timewin
    acc_reverse_day2 = [acc_reverse_day2;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
load('D:\monkeyreverse\firingrate\20211208_ab_reverse_all_firingrate_001.mat')
acc_reverse_day3 = [];
for i = 1:slide:size(condition_rw,1)-timewin
    acc_reverse_day3 = [acc_reverse_day3;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end

a_min = min([size(acc_a,1),size(acc_a_day2,1),size(acc_a_day3,1)]);
b_min = min([size(acc_b,1),size(acc_b_day2,1),size(acc_b_day3,1)]);
rea_min = min([size(acc_rea,1),size(acc_rea_day2,1),size(acc_rea_day3,1)]);
reverse_min = min([size(acc_reverse,1),size(acc_reverse_day2,1),size(acc_reverse_day3,1)]);

a_max = max([size(acc_a,1),size(acc_a_day2,1),size(acc_a_day3,1)]);
b_max = max([size(acc_b,1),size(acc_b_day2,1),size(acc_b_day3,1)]);
rea_max = max([size(acc_rea,1),size(acc_rea_day2,1),size(acc_rea_day3,1)]);
reverse_max = max([size(acc_reverse,1),size(acc_reverse_day2,1),size(acc_reverse_day3,1)]);

acc_a_mean = [];
acc_a_var = [];
acc_a_max = [];
acc_a_min = [];
acc_b_mean = [];
acc_b_var = [];
acc_b_max = [];
acc_b_min = [];
acc_rea_mean = [];
acc_rea_var = [];
acc_rea_max = [];
acc_rea_min = [];
acc_reverse_mean = [];
acc_reverse_var = [];
acc_reverse_max = [];
acc_reverse_min = [];


for i = 1:1:a_max
    if i <= a_min
        acc_a_mean = [acc_a_mean;mean([acc_a(i,1),acc_a_day2(i,1),acc_a_day3(i,1)])];
        acc_a_var = [acc_a_var;std([acc_a(i,1),acc_a_day2(i,1),acc_a_day3(i,1)])]; 
        acc_a_min = [acc_a_min;min([acc_a(i,1),acc_a_day2(i,1),acc_a_day3(i,1)])]; 
        acc_a_max = [acc_a_max;max([acc_a(i,1),acc_a_day2(i,1),acc_a_day3(i,1)])]; 
    elseif i>a_min &&  i<= size(acc_a_day2,1)
        acc_a_mean = [acc_a_mean;mean([acc_a(i,1),acc_a_day2(i,1)])];
        acc_a_var = [acc_a_var;std([acc_a(i,1),acc_a_day2(i,1)])];
        acc_a_min = [acc_a_min;min([acc_a(i,1),acc_a_day2(i,1)])]; 
        acc_a_max = [acc_a_max;max([acc_a(i,1),acc_a_day2(i,1)])]; 
    else
        acc_a_mean = [acc_a_mean;acc_a(i,1)];
        acc_a_var = [acc_a_var;0];
        acc_a_min = [acc_a_min;acc_a(i,1)]; 
        acc_a_max = [acc_a_max;acc_a(i,1)]; 
    end
end
for i = 1:1:b_max
    if i <= b_min
        acc_b_mean = [acc_b_mean;mean([acc_b(i,1),acc_b_day2(i,1),acc_b_day3(i,1)])];
        acc_b_var = [acc_b_var;std([acc_b(i,1),acc_b_day2(i,1),acc_b_day3(i,1)])];
        acc_b_min = [acc_b_min;min([acc_b(i,1),acc_b_day2(i,1),acc_b_day3(i,1)])]; 
        acc_b_max = [acc_b_max;max([acc_b(i,1),acc_b_day2(i,1),acc_b_day3(i,1)])]; 
    else
        acc_b_mean = [acc_b_mean;acc_b_day3(i,1)];
        acc_b_var = [acc_b_var;0];
        acc_b_min = [acc_b_min;acc_b_day3(i,1)]; 
        acc_b_max = [acc_b_max;acc_b_day3(i,1)]; 
    end
end
for i = 1:1:rea_max
        acc_rea_mean = [acc_rea_mean;mean([acc_rea(i,1),acc_rea_day2(i,1),acc_rea_day3(i,1)])];
        acc_rea_var = [acc_rea_var;std([acc_rea(i,1),acc_rea_day2(i,1),acc_rea_day3(i,1)])];
        acc_rea_min = [acc_rea_min;min([acc_rea(i,1),acc_rea_day2(i,1),acc_rea_day3(i,1)])]; 
        acc_rea_max = [acc_rea_max;max([acc_rea(i,1),acc_rea_day2(i,1),acc_rea_day3(i,1)])]; 
end
for i = 1:1:reverse_max
    if i <= reverse_min
        acc_reverse_mean = [acc_reverse_mean;mean([acc_reverse(i,1),acc_reverse_day2(i,1),acc_reverse_day3(i,1)])];
        acc_reverse_var = [acc_reverse_var;std([acc_reverse(i,1),acc_reverse_day2(i,1),acc_reverse_day3(i,1)])];
        acc_reverse_min = [acc_reverse_min;min([acc_reverse(i,1),acc_reverse_day2(i,1),acc_reverse_day3(i,1)])]; 
        acc_reverse_max = [acc_reverse_max;max([acc_reverse(i,1),acc_reverse_day2(i,1),acc_reverse_day3(i,1)])]; 
    elseif i>reverse_min &&  i<= size(acc_reverse_day3,1)
        acc_reverse_mean = [acc_reverse_mean;mean([acc_reverse(i,1),acc_reverse_day3(i,1)])];
        acc_reverse_var = [acc_reverse_var;std([acc_reverse_day3(i,1),acc_reverse(i,1)])];
        acc_reverse_min = [acc_reverse_min;min([acc_reverse(i,1),acc_reverse_day3(i,1)])]; 
        acc_reverse_max = [acc_reverse_max;max([acc_reverse(i,1),acc_reverse_day3(i,1)])]; 
    else
        acc_reverse_mean = [acc_reverse_mean;acc_reverse(i,1)];
        acc_reverse_var = [acc_reverse_var;0];
        acc_reverse_min = [acc_reverse_min;acc_reverse(i,1)]; 
        acc_reverse_max = [acc_reverse_max;acc_reverse(i,1)]; 
    end
end


c_map_new = [176/255, 108/255, 109/255
             56/255, 104/255, 142/255
             175/255, 143/255, 208/255
             114/255, 111/255, 122/255];
     

% smmoth filter
a_smmoth = smoothdata(acc_a_mean,'lowess');
a_smmoth_down = smoothdata(acc_a_mean-acc_a_var,'lowess');
a_smmoth_up = smoothdata(acc_a_mean+acc_a_var,'lowess');
b_smmoth = smoothdata(acc_b_mean,'lowess');
b_smmoth_down = smoothdata(acc_b_mean-acc_b_var,'lowess');
b_smmoth_up = smoothdata(acc_b_mean+acc_b_var,'lowess');
rea_smmoth = smoothdata(acc_rea_mean,'lowess') ;
rea_smmoth_down = smoothdata(acc_rea_mean-acc_rea_var,'lowess');
rea_smmoth_up = smoothdata(acc_rea_mean+acc_rea_var,'lowess');
reverse_smmoth = smoothdata(acc_reverse_mean,'lowess');
reverse_smmoth_down = smoothdata(acc_reverse_mean-acc_reverse_var,'lowess');
reverse_smmoth_up = smoothdata(acc_reverse_mean+acc_reverse_var,'lowess');

% learning speed plot
fig = figure('Position',[495 186 400 300],...    
'Name','response-time figure',...
'NumberTitle','off',...
'Color','w',...
'Menubar','none');
E1 = plot(a_smmoth, 'Color', c_map_new(1,:),'LineWidth', 2)
hold on
x = [1:1:size(a_smmoth,1)];
patch([x,fliplr(x)],[a_smmoth_down',fliplr(a_smmoth_up')],c_map_new(1,:),'EdgeColor','none')
alpha(0.2);
hold on
E2 = plot(b_smmoth, 'Color', c_map_new(2,:),'LineWidth', 2)
hold on
x = [1:1:size(b_smmoth,1)];
patch([x,fliplr(x)],[b_smmoth_down',fliplr(b_smmoth_up')],c_map_new(2,:),'EdgeColor','none')
alpha(0.2);
hold on
E3 = plot(rea_smmoth, 'Color', c_map_new(3,:),'LineWidth', 2)
hold on
x = [1:1:size(rea_smmoth,1)];
patch([x,fliplr(x)],[rea_smmoth_down',fliplr(rea_smmoth_up')],c_map_new(3,:),'EdgeColor','none')
alpha(0.2);
hold on
E4 = plot(reverse_smmoth, 'Color', c_map_new(4,:),'LineWidth', 2)
hold on
x = [1:1:size(reverse_smmoth,1)];
patch([x,fliplr(x)],[reverse_smmoth_down',fliplr(reverse_smmoth_up')],c_map_new(4,:),'EdgeColor','none')
alpha(0.2);
hold on
box off
yline(0.9,'--','LineWidth',3)
xlabel('Trial')
ylabel('Accuracy')
set(gca,'YLim',[0 1]);
axis([1,size(acc_reverse_day3,1)+10,0,1])
h =gca;
h.LineWidth = 1.5;

% trials numbers need to reach 90% percent correct
numm=1;slide = 1;
blocka_accindx = find(acc_a>=0.9);
blocka_accindx = blocka_accindx(numm)*slide;
blocka_accindx_day2 = find(acc_a_day2>=0.9);
blocka_accindx_day2 = blocka_accindx_day2(numm)*slide;
blocka_accindx_day3 = find(acc_a_day3>=0.9);
blocka_accindx_day3 = blocka_accindx_day3(numm)*slide;
blockb_accindx = find(acc_b>=0.9);
blockb_accindx =blockb_accindx(numm)*slide;
blockb_accindx_day2 = find(acc_b_day2>=0.9);
blockb_accindx_day2 =blockb_accindx_day2(numm)*slide;
blockb_accindx_day3 = find(acc_b_day3>=0.9);
blockb_accindx_day3 = blockb_accindx_day3(numm)*slide;
blockrea_accindx = find(acc_rea>=0.9);
blockrea_accindx = blockrea_accindx(numm)*slide;
blockrea_accindx_day2 = find(acc_rea_day2>=0.9);
blockrea_accindx_day2 =blockrea_accindx_day2(numm)*slide;
blockrea_accindx_day3 = find(acc_rea_day3>=0.9);
blockrea_accindx_day3 = blockrea_accindx_day3(numm)*slide;
blockreverse_accindx = find(acc_reverse>=0.9);
if isempty(blockreverse_accindx) || size(blockreverse_accindx,1)<numm
    blockreverse_accindx = size(acc_reverse,1);
else
    blockreverse_accindx = blockreverse_accindx(numm)*slide;
end
blockreverse_accindx_day2 = find(acc_reverse_day2>=0.9);
if isempty(blockreverse_accindx_day2) || size(blockreverse_accindx_day2,1)<numm
    blockreverse_accindx_day2 = size(acc_reverse,1);;
else
    blockreverse_accindx_day2 = blockreverse_accindx_day2 (numm)*slide;
end
blockreverse_accindx_day3 = find(acc_reverse_day3>=0.9);
if isempty(blockreverse_accindx_day3)|| size(blockreverse_accindx_day3,1)<numm
    blockreverse_accindx_day3 = size(acc_reverse,1);
else
    blockreverse_accindx_day3 = blockreverse_accindx_day3(numm)*slide;
end
a_trail_mean = mean([blocka_accindx,blocka_accindx_day2,blocka_accindx_day3]);
b_trail_mean = mean([blockb_accindx,blockb_accindx_day2,blockb_accindx_day3]);
rea_trail_mean = mean([blockrea_accindx,blockrea_accindx_day2,blockrea_accindx_day3]);
reverse_trail_mean = mean([blockreverse_accindx,blockreverse_accindx_day2,blockreverse_accindx_day3],2);
a_trail_std = std([blocka_accindx,blocka_accindx_day2,blocka_accindx_day3]);
b_trail_std = std([blockb_accindx,blockb_accindx_day2,blockb_accindx_day3]);
rea_trail_std = std([blockrea_accindx,blockrea_accindx_day2,blockrea_accindx_day3]);
reverse_trail_std = std([blockreverse_accindx,blockreverse_accindx_day2,blockreverse_accindx_day3]);

c_map_new = [176/255, 108/255, 109/255; 56/255, 104/255, 142/255; 175/255, 143/255, 208/255; 114/255, 111/255, 122/255];

boxplot([blocka_accindx,blocka_accindx_day2,blocka_accindx_day3;blockb_accindx,blockb_accindx_day2,blockb_accindx_day3;blockrea_accindx,blockrea_accindx_day2,blockrea_accindx_day3;blockreverse_accindx,blockreverse_accindx_day2,blockreverse_accindx_day3]');
boxplot([blocka_accindx,blocka_accindx_day2,blocka_accindx_day3,blockb_accindx,blockb_accindx_day2,blockb_accindx_day3,blockrea_accindx,blockrea_accindx_day2,blockrea_accindx_day3,blockreverse_accindx,blockreverse_accindx_day2,blockreverse_accindx_day3],[1,1,1,2,2,2,2,2,2,3,3,3],'Colors',c_map_new,'Symbol','o','OutlierSize',5);
boxobj = findobj(gca, 'Tag', 'Box')

for i = 1:length(boxobj)
    patch(get(boxobj(i), 'XData'), get(boxobj(i), 'YData'), c_map_new(i,:), 'FaceAlpha', 0.5)
end
hold on
plot([1 2 3],[mean([blocka_accindx,blocka_accindx_day2,blocka_accindx_day3]),mean([blockb_accindx,blockb_accindx_day2,blockb_accindx_day3,blockrea_accindx,blockrea_accindx_day2,blockrea_accindx_day3]),mean([blockreverse_accindx,blockreverse_accindx_day2,blockreverse_accindx_day3])],'color',[128/255,128/255,128/255],'LineWidth',2)
hold on  
scatter([1 2 3],[mean([blocka_accindx,blocka_accindx_day2,blocka_accindx_day3]),mean([blockb_accindx,blockb_accindx_day2,blockb_accindx_day3,blockrea_accindx,blockrea_accindx_day2,blockrea_accindx_day3]),mean([blockreverse_accindx,blockreverse_accindx_day2,blockreverse_accindx_day3])],'color',[128/255,128/255,128/255],20,c_map_new,'filled')

scatter([1,1,1],[blocka_accindx,blocka_accindx_day2,blocka_accindx_day3],[],c_map_new(1,:),'filled')
hold on 
scatter([2,2,2],[blockb_accindx,blockb_accindx_day2,blockb_accindx_day3],[],c_map_new(2,:),'filled')
hold on 
scatter([3,3,3],[blockrea_accindx,blockrea_accindx_day2,blockrea_accindx_day3],[],c_map_new(3,:),'filled')
hold on
scatter([4,4,4],[blockreverse_accindx,blockreverse_accindx_day2,blockreverse_accindx_day3],[],c_map_new(4,:),'filled')
hold on 

plot([1:4],[a_trail_mean, b_trail_mean, rea_trail_mean, reverse_trail_mean],'color',[255/255,153/255,153/255],'LineWidth',2.5)

