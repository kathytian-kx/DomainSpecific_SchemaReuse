%behavior analysis for two monkey
clc
clear
load('D:\monkeyreverse\firingrate\20211201_ab_cl_new_all_firingrate_001.mat')

blocka_indx = [];
blockb_indx = [];
blockrea_indx = [];
for i = 1:1:size(condition_rw,1)-1
    if (conditions_played(:,i)== 1 || conditions_played(:,i)== 2) && (conditions_played(:,i+1)==3 || conditions_played(:,i+1)==4)
        blocka_indx = i;
    elseif (conditions_played(:,i)== 3 || conditions_played(:,i)== 4) && (conditions_played(:,i+1)==1 || conditions_played(:,i+1)==2)
        blockb_indx = i;
    end
end
blockrea_indx = size(condition_rw,1);

timewin = 19;
slide = 1;
acc_a = [];
acc_b = [];
acc_rea = [];
for i = 1:slide:blocka_indx-timewin
    acc_a = [acc_a;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
for i = blocka_indx+1:slide:blockb_indx-timewin
    acc_b = [acc_b;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
for i = blockb_indx+1:slide:blockrea_indx-timewin
    acc_rea = [acc_rea;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end

load('D:\monkeyreverse\firingrate\20211205_ab_cl_new_all_firingrate_001.mat')

blocka_indx_day2 = [];
blockb_indx_day2 = [];
blockrea_indx_day2 = [];
for i = 1:1:size(condition_rw,1)-1
    if (conditions_played(:,i)== 1 || conditions_played(:,i)== 2) && (conditions_played(:,i+1)==3 || conditions_played(:,i+1)==4)
        blocka_indx_day2 = i;
    elseif (conditions_played(:,i)== 3 || conditions_played(:,i)== 4) && (conditions_played(:,i+1)==1 || conditions_played(:,i+1)==2)
        blockb_indx_day2 = i;
    end
end
blockrea_indx_day2 = size(condition_rw,1);


acc_a_day2 = [];
acc_b_day2 = [];
acc_rea_day2 = [];
for i = 1:slide:blocka_indx_day2-timewin
    acc_a_day2 = [acc_a_day2;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
for i = blocka_indx_day2+1:slide:blockb_indx_day2-timewin
    acc_b_day2 = [acc_b_day2;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
for i = blockb_indx_day2+1:slide:blockrea_indx_day2-timewin
    acc_rea_day2 = [acc_rea_day2;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end

load('D:\monkeyreverse\firingrate\20211208_ab_cl_new_all_firingrate_001.mat')

blocka_indx_day3 = [];
blockb_indx_day3 = [];
blockrea_indx_day3 = [];
for i = 1:1:size(condition_rw,1)-1
    if (conditions_played(:,i)== 1 || conditions_played(:,i)== 2) && (conditions_played(:,i+1)==3 || conditions_played(:,i+1)==4)
        blocka_indx_day3 = i;
    elseif (conditions_played(:,i)== 3 || conditions_played(:,i)== 4) && (conditions_played(:,i+1)==1 || conditions_played(:,i+1)==2)
        blockb_indx_day3 = i;
    end
end
blockrea_indx_day3 = size(condition_rw,1);

acc_a_day3 = [];
acc_b_day3 = [];
acc_rea_day3 = [];
for i = 1:slide:blocka_indx_day3-timewin
    acc_a_day3 = [acc_a_day3;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
for i = blocka_indx_day3+1:slide:blockb_indx_day3-timewin
    acc_b_day3 = [acc_b_day3;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
for i = blockb_indx_day3+1:slide:blockrea_indx_day3-timewin
    acc_rea_day3 = [acc_rea_day3;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end

load('D:\monkeyreverse\firingrate\20211201_ab_reverse_all_firingrate_001.mat')
acc_reverse = [];
for i = 1:slide:size(condition_rw,1)-timewin
    acc_reverse = [acc_reverse;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
load('D:\monkeyreverse\firingrate\20211205_ab_reverse_all_firingrate_001.mat')
acc_reverse_day2 = [];
for i = 1:slide:size(condition_rw,1)-timewin
    acc_reverse_day2 = [acc_reverse_day2;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
load('D:\monkeyreverse\firingrate\20211208_ab_reverse_all_firingrate_001.mat')
acc_reverse_day3 = [];
for i = 1:slide:size(condition_rw,1)-timewin
    acc_reverse_day3 = [acc_reverse_day3;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end

numm=1;
ab_blocka_accindx = find(acc_a>=0.9);
ab_blocka_accindx = ab_blocka_accindx(numm)*slide;
ab_blocka_accindx_day2 = find(acc_a_day2>=0.9);
ab_blocka_accindx_day2 = ab_blocka_accindx_day2(numm)*slide;
ab_blocka_accindx_day3 = find(acc_a_day3>=0.9);
ab_blocka_accindx_day3 = ab_blocka_accindx_day3(numm)*slide;
ab_blockb_accindx = find(acc_b>=0.9);
ab_blockb_accindx =ab_blockb_accindx(numm)*slide;
ab_blockb_accindx_day2 = find(acc_b_day2>=0.9);
ab_blockb_accindx_day2 =ab_blockb_accindx_day2(numm)*slide;
ab_blockb_accindx_day3 = find(acc_b_day3>=0.9);
ab_blockb_accindx_day3 = ab_blockb_accindx_day3(numm)*slide;
ab_blockrea_accindx = find(acc_rea>=0.9);
ab_blockrea_accindx = ab_blockrea_accindx(numm)*slide;
ab_blockrea_accindx_day2 = find(acc_rea_day2>=0.9);
ab_blockrea_accindx_day2 =ab_blockrea_accindx_day2(numm)*slide;
ab_blockrea_accindx_day3 = find(acc_rea_day3>=0.9);
ab_blockrea_accindx_day3 = ab_blockrea_accindx_day3(numm)*slide;
ab_blockreverse_accindx = find(acc_reverse>=0.9);
if isempty(ab_blockreverse_accindx) || size(ab_blockreverse_accindx,1)<numm
    ab_blockreverse_accindx = size(acc_reverse,1);
else
    ab_blockreverse_accindx = ab_blockreverse_accindx(numm)*slide;
end
ab_blockreverse_accindx_day2 = find(acc_reverse_day2>=0.9);
if isempty(ab_blockreverse_accindx_day2) || size(ab_blockreverse_accindx_day2,1)<numm
    ab_blockreverse_accindx_day2 = size(acc_reverse_day2,1);
else
    ab_blockreverse_accindx_day2 = ab_blockreverse_accindx_day2 (numm)*slide;
end
ab_blockreverse_accindx_day3 = find(acc_reverse_day3>=0.9);
if isempty(ab_blockreverse_accindx_day3)|| size(ab_blockreverse_accindx_day3,1)<numm
    ab_blockreverse_accindx_day3 = size(acc_reverse_day3,1);
else
    ab_blockreverse_accindx_day3 = ab_blockreverse_accindx_day3(numm)*slide;
end
ab_a_trail_mean = mean([ab_blocka_accindx,ab_blocka_accindx_day2,ab_blocka_accindx_day3]);
ab_b_trail_mean = mean([ab_blockb_accindx,ab_blockb_accindx_day2,ab_blockb_accindx_day3]);
ab_rea_trail_mean = mean([ab_blockrea_accindx,ab_blockrea_accindx_day2,ab_blockrea_accindx_day3]);
ab_reverse_trail_mean = mean([ab_blockreverse_accindx,ab_blockreverse_accindx_day2,ab_blockreverse_accindx_day3],2);
ab_a_trail_std = std([ab_blocka_accindx,ab_blocka_accindx_day2,ab_blocka_accindx_day3]);
ab_b_trail_std = std([ab_blockb_accindx,ab_blockb_accindx_day2,ab_blockb_accindx_day3]);
ab_rea_trail_std = std([ab_blockrea_accindx,ab_blockrea_accindx_day2,ab_blockrea_accindx_day3]);
ab_reverse_trail_std = std([ab_blockreverse_accindx,ab_blockreverse_accindx_day2,ab_blockreverse_accindx_day3]);


load('D:\monkeyreverse\firingrate\20211118_zz_cl_new_all_firingrate_001.mat')
blocka_indx = [];
blockb_indx = [];
blockrea_indx = [];
for i = 1:1:size(condition_rw,1)-1
    if (conditions_played(:,i)== 1 || conditions_played(:,i)== 2) && (conditions_played(:,i+1)==3 || conditions_played(:,i+1)==4)
        blocka_indx = i;
    elseif (conditions_played(:,i)== 3 || conditions_played(:,i)== 4) && (conditions_played(:,i+1)==1 || conditions_played(:,i+1)==2)
        blockb_indx = i;
    end
end
blockrea_indx = size(condition_rw,1);


acc_a = [];
acc_b = [];
acc_rea = [];
for i = 1:slide:blocka_indx-timewin
    acc_a = [acc_a;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
for i = blocka_indx+1:slide:blockb_indx-timewin
    acc_b = [acc_b;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
for i = blockb_indx+1:slide:blockrea_indx-timewin
    acc_rea = [acc_rea;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end

load('D:\monkeyreverse\firingrate\20211124_zz_cl_new_all_firingrate_001.mat')

blocka_indx_day2 = [];
blockb_indx_day2 = [];
blockrea_indx_day2 = [];
for i = 1:1:size(condition_rw,1)-1
    if (conditions_played(:,i)== 1 || conditions_played(:,i)== 2) && (conditions_played(:,i+1)==3 || conditions_played(:,i+1)==4)
        blocka_indx_day2 = i;
    elseif (conditions_played(:,i)== 3 || conditions_played(:,i)== 4) && (conditions_played(:,i+1)==1 || conditions_played(:,i+1)==2)
        blockb_indx_day2 = i;
    end
end
blockrea_indx_day2 = size(condition_rw,1);

acc_a_day2 = [];
acc_b_day2 = [];
acc_rea_day2 = [];
for i = 1:slide:blocka_indx_day2-timewin
    acc_a_day2 = [acc_a_day2;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
for i = blocka_indx_day2+1:slide:blockb_indx_day2-timewin
    acc_b_day2 = [acc_b_day2;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
for i = blockb_indx_day2+1:slide:blockrea_indx_day2-timewin
    acc_rea_day2 = [acc_rea_day2;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end

load('D:\monkeyreverse\firingrate\20211125_zz_cl_new_all_firingrate_001.mat')

blocka_indx_day3 = [];
blockb_indx_day3 = [];
blockrea_indx_day3 = [];
for i = 1:1:size(condition_rw,1)-1
    if (conditions_played(:,i)== 1 || conditions_played(:,i)== 2) && (conditions_played(:,i+1)==3 || conditions_played(:,i+1)==4)
        blocka_indx_day3 = i;
    elseif (conditions_played(:,i)== 3 || conditions_played(:,i)== 4) && (conditions_played(:,i+1)==1 || conditions_played(:,i+1)==2)
        blockb_indx_day3 = i;
    end
end
blockrea_indx_day3 = size(condition_rw,1);


acc_a_day3 = [];
acc_b_day3 = [];
acc_rea_day3 = [];
for i = 1:slide:blocka_indx_day3-timewin
    acc_a_day3 = [acc_a_day3;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
for i = blocka_indx_day3+1:slide:blockb_indx_day3-timewin
    acc_b_day3 = [acc_b_day3;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
for i = blockb_indx_day3+1:slide:blockrea_indx_day3-timewin
    acc_rea_day3 = [acc_rea_day3;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end

load('D:\monkeyreverse\firingrate\20211118_zz_reverse_all_firingrate_001.mat')
acc_reverse = [];
for i = 1:slide:size(condition_rw,1)-timewin
    acc_reverse = [acc_reverse;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
load('D:\monkeyreverse\firingrate\20211124_zz_reverse_all_firingrate_001.mat')
acc_reverse_day2 = [];
for i = 1:slide:size(condition_rw,1)-timewin
    acc_reverse_day2 = [acc_reverse_day2;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end
load('D:\monkeyreverse\firingrate\20211125_zz_reverse_all_firingrate_001.mat')
acc_reverse_day3 = [];
for i = 1:slide:size(condition_rw,1)-timewin
    acc_reverse_day3 = [acc_reverse_day3;size(find(condition_rw(i:i+timewin,:) == 1),1)/(timewin+1)];
end

zz_blocka_accindx = find(acc_a>=0.9);
zz_blocka_accindx = zz_blocka_accindx(numm)*slide;
zz_blocka_accindx_day2 = find(acc_a_day2>=0.9);
zz_blocka_accindx_day2 = zz_blocka_accindx_day2(numm)*slide;
zz_blocka_accindx_day3 = find(acc_a_day3>=0.9);
zz_blocka_accindx_day3 = zz_blocka_accindx_day3(numm)*slide;
zz_blockb_accindx = find(acc_b>=0.9);
zz_blockb_accindx =zz_blockb_accindx(numm)*slide;
zz_blockb_accindx_day2 = find(acc_b_day2>=0.9);
zz_blockb_accindx_day2 =zz_blockb_accindx_day2(numm)*slide;
zz_blockb_accindx_day3 = find(acc_b_day3>=0.9);
zz_blockb_accindx_day3 = zz_blockb_accindx_day3(numm)*slide;
zz_blockrea_accindx = find(acc_rea>=0.9);
zz_blockrea_accindx = zz_blockrea_accindx(numm)*slide;
zz_blockrea_accindx_day2 = find(acc_rea_day2>=0.9);
zz_blockrea_accindx_day2 =zz_blockrea_accindx_day2(numm)*slide;
zz_blockrea_accindx_day3 = find(acc_rea_day3>=0.9);
zz_blockrea_accindx_day3 = zz_blockrea_accindx_day3(numm)*slide;
zz_blockreverse_accindx = find(acc_reverse>=0.9);
if isempty(zz_blockreverse_accindx) || size(zz_blockreverse_accindx,1)<numm
    zz_blockreverse_accindx = size(acc_reverse,1);
else
    zz_blockreverse_accindx = zz_blockreverse_accindx(numm)*slide;
end
zz_blockreverse_accindx_day2 = find(acc_reverse_day2>=0.9);
if isempty(zz_blockreverse_accindx_day2) || size(zz_blockreverse_accindx_day2,1)<numm
    zz_blockreverse_accindx_day2 = size(acc_reverse_day2,1);
else
    zz_blockreverse_accindx_day2 =zz_blockreverse_accindx_day2 (numm)*slide;
end
zz_blockreverse_accindx_day3 = find(acc_reverse_day3>=0.9);
if isempty(zz_blockreverse_accindx_day3) || size(zz_blockreverse_accindx_day3,1)<numm
    zz_blockreverse_accindx_day3 = size(acc_reverse_day3,1);
else
    zz_blockreverse_accindx_day3 = zz_blockreverse_accindx_day3(numm)*slide;
end
zz_a_trail_mean = mean([zz_blocka_accindx,zz_blocka_accindx_day2,zz_blocka_accindx_day3]);
zz_b_trail_mean = mean([zz_blockb_accindx,zz_blockb_accindx_day2,zz_blockb_accindx_day3]);
zz_rea_trail_mean = mean([zz_blockrea_accindx,zz_blockrea_accindx_day2,zz_blockrea_accindx_day3]);
zz_reverse_trail_mean = mean([zz_blockreverse_accindx,zz_blockreverse_accindx_day2,zz_blockreverse_accindx_day3],2);
zz_a_trail_std = std([zz_blocka_accindx,zz_blocka_accindx_day2,zz_blocka_accindx_day3]);
zz_b_trail_std = std([zz_blockb_accindx,zz_blockb_accindx_day2,zz_blockb_accindx_day3]);
zz_rea_trail_std = std([zz_blockrea_accindx,zz_blockrea_accindx_day2,zz_blockrea_accindx_day3]);
zz_reverse_trail_std = std([zz_blockreverse_accindx,zz_blockreverse_accindx_day2,zz_blockreverse_accindx_day3]);


a_trail_mean = mean([ab_blocka_accindx,ab_blocka_accindx_day2,ab_blocka_accindx_day3,zz_blocka_accindx,zz_blocka_accindx_day2,zz_blocka_accindx_day3]);
a_trail_std = std([ab_blocka_accindx,ab_blocka_accindx_day2,ab_blocka_accindx_day3,zz_blocka_accindx,zz_blocka_accindx_day2,zz_blocka_accindx_day3]);
brea_trail_mean = mean([ab_blockb_accindx,ab_blockb_accindx_day2,ab_blockb_accindx_day3,zz_blockb_accindx,zz_blockb_accindx_day2,zz_blockb_accindx_day3,ab_blockrea_accindx,ab_blockrea_accindx_day2,ab_blockrea_accindx_day3,zz_blockrea_accindx,zz_blockrea_accindx_day2,zz_blockrea_accindx_day3]);
brea_trail_std = std([ab_blockb_accindx,ab_blockb_accindx_day2,ab_blockb_accindx_day3,zz_blockb_accindx,zz_blockb_accindx_day2,zz_blockb_accindx_day3,ab_blockrea_accindx,ab_blockrea_accindx_day2,ab_blockrea_accindx_day3,zz_blockrea_accindx,zz_blockrea_accindx_day2,zz_blockrea_accindx_day3]);
reverse_trail_mean = mean([ab_blockreverse_accindx,ab_blockreverse_accindx_day2,ab_blockreverse_accindx_day3,zz_blockreverse_accindx,zz_blockreverse_accindx_day2,zz_blockreverse_accindx_day3]);
reverse_trail_std = std([ab_blockreverse_accindx,ab_blockreverse_accindx_day2,ab_blockreverse_accindx_day3,zz_blockreverse_accindx,zz_blockreverse_accindx_day2,zz_blockreverse_accindx_day3]);


fig = figure('Position',[495 186 200 155],... 
'NumberTitle','off',...
'Color','w',...
'Menubar','none');

c_map_new = [176/255, 108/255, 109/255; 56/255, 104/255, 142/255; 175/255, 143/255, 208/255; 114/255, 111/255, 122/255];

x = [a_trail_mean, brea_trail_mean, reverse_trail_mean]; % x轴数据
errors = [a_trail_std, brea_trail_std, reverse_trail_std];
y = [1, 2.5, 4]; % y轴数据


for i=1:3
b = bar(y(i),x(i),0.75,'stacked');
hold on
set(b(1),'facecolor',c_map_new(i,:))
end

hold on
errorbar( y,x, errors, 'k', 'LineStyle', 'none');

data = {};

data{1,1} = {[ab_blocka_accindx,ab_blocka_accindx_day2,ab_blocka_accindx_day3,zz_blocka_accindx,zz_blocka_accindx_day2,zz_blocka_accindx_day3]};
data{1,2} = {[ab_blockrea_accindx,ab_blockrea_accindx_day2,ab_blockrea_accindx_day3,zz_blockrea_accindx,zz_blockrea_accindx_day2,zz_blockrea_accindx_day3,ab_blockb_accindx,ab_blockb_accindx_day2,ab_blockb_accindx_day3,zz_blockb_accindx,zz_blockb_accindx_day2,zz_blockb_accindx_day3]};
data{1,3} = {[ab_blockreverse_accindx,ab_blockreverse_accindx_day2,ab_blockreverse_accindx_day3,zz_blockreverse_accindx,zz_blockreverse_accindx_day2,zz_blockreverse_accindx_day3]};



for i = 1:1:2
    for j = i+1:1:3
        [h,p,ci,stats] = ttest2(data{1,i}{1,1},data{1,j}{1,1});
        if p>=0.05
            tttest_result(i,j) = 0;
        elseif p>=0.01 && p<0.05
            tttest_result(i,j) = 1;
        elseif p>= 0.001 && p <0.01
            tttest_result(i,j) = 2;
        else
            tttest_result(i,j) = 3;
        end
    end
end


ylabel('Trial');

set(gca,'XTick',[1 2 3])
xlabels={'A', 'B & Revisit A','Review A'};
set(gca,'XTickLabel',xlabels)

for i=1:length(ytick)
   yticklabel{i}=sprintf('%d',ytick(i));
end
set(gca,'yTickLabel', yticklabel, 'FontSize', 12, 'FontName', 'Times New Roman'); %修改坐标名称、字体
 
set(gca,'XLim',[0 4]);
set(gca,'XTick',[0:1:4]);
set(gca,'XTickLabel',[0:1:4]);
set(gca,'YLim',[0 300]);
set(gca,'YTick',[0:100:300]);
set(gca,'YTickLabel',[0:100:300]);
box off
set(gca,'linewidth',0.5)

print('twomonkeybehavior.eps','-depsc');
