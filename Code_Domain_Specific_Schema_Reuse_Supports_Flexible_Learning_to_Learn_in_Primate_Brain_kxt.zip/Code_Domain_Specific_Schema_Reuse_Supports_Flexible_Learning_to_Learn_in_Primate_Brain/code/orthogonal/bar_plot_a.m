% bar plot: ratio of days around 90 degree. 
% Error bar plot 
% Significance plot.

orth_statics_name = 'orthogonal_statics.mat'; 
load(orth_statics_name);

monkeys = {'ab', 'zz'};
bar_data = zeros(length(monkeys), 2);
errorbar_data = zeros(length(monkeys), 2);
p_val = zeros(length(monkeys), 1);

for i=1:length(monkeys)
    monkey = monkeys{i};
    monkey_idx = find(arrayfun(@(x) contains(x.name, monkey), orthogonal_statics));
    ang = [orthogonal_statics(monkey_idx).subspace_angle];
	ang_shuff = [orthogonal_statics(monkey_idx).ang_shuff_subspace];
    ang_shuff(ang_shuff == -1) = [];
    
    % ratio: from 80-100 degree
    bar_data(i, 1) = mean(ang);
    bar_data(i, 2) = mean(ang_shuff);
    
    % errorbar
    errorbar_data(i, 1) = std(ang) / sqrt(length(ang));
    errorbar_data(i, 2) = std(ang_shuff) / sqrt(length(ang_shuff));
    
    % significance
    [~, p_val(i)] = ttest2(ang, ang_shuff, 'Tail', 'right', 'Alpha', 0.05);
end

%% plot
% figure config
fig = figure('Position', [495, 186, 800, 600], ...
    'Name', 'orth_statics figure', ...
    'NumberTitle', 'off',...
    'Color', 'w',...
    'Menubar', 'none');
fontsize = 6;

% plot bar
bar(bar_data);
ylim([0, 100]);
set(gca, 'XTickLabel', monkeys);
yline(90, 'k--');
hold on

% error bar plot
ngroups = length(monkeys);
nbars = 2;
groupwidth = min(0.8, nbars/(nbars + 1.5));
errorbar_x = zeros(ngroups, nbars);

for i = 1:nbars
    x = (1:ngroups) - groupwidth/2 + (2*i-1) * groupwidth / (2*nbars);
    errorbar(x, bar_data(:,i), errorbar_data(:,i), '.');
    errorbar_x(:, i) = x;
end

% significance plot
stars = {'***', '**', '*'};
stars_pval = [0.01, 0.05, 0.1];
stars_yline_y = 95;

for i=1:ngroups
    plot([errorbar_x(i, 1), errorbar_x(i, 2)], [stars_yline_y, stars_yline_y], 'k',...
         'LineWidth', 1);
    pval = p_val(i);
    stars_plot = 1;
    if pval < stars_pval(1)
        text_ = stars{1};
        stars_x = errorbar_x(i, 1) + (errorbar_x(i, 2)-errorbar_x(i, 1))/(ngroups+2);
    elseif pval < stars_pval(2)
        text_ = stars{2};
        stars_x = errorbar_x(i, 1) + (errorbar_x(i, 2)-errorbar_x(i, 1))/(ngroups+1);
    elseif pval <stars_pval(3)
        text_ = stars{3};
        stars_x = errorbar_x(i, 1) + (errorbar_x(i, 2)-errorbar_x(i, 1))/ngroups;
    else
        warning('p value exceed 0.1??');
        stars_plot = 0;
    end
    if stars_plot == 1
        text(stars_x, stars_yline_y + 1, text_, 'FontSize', fontsize);
    else
        text((errorbar_x(i, 1)*0.875 + errorbar_x(i, 2)*0.125), stars_yline_y + 2.5, sprintf("p=%s", num2str(pval, '%.2f')), 'FontSize', fontsize);
    end
end

title('Angle Between Stimulus Subspace and Decision Subspace')

ax = gca;
latexHandle = text(ax.YAxis.Label.Position(1)-0.03, ax.YAxis.Label.Position(2)+6,...
                   '($^{\circ})$', 'Interpreter', 'latex', 'FontSize', fontsize, 'Rotation', 90);

xlabel('Monkey');
ylabel('Angle');

legend({'original', 'shuffled'}, 'Position',[0.75 0.7 0.15 0.0869]');
% legend({'original', 'shuffled'}, 'Location', 'NorthEast');
set(gca, 'FontName', 'Arial');
set(gca, 'LineWidth', 1.5);

% set fontsize and title fontsize
ax.FontSize = fontsize;
ax.TitleFontSizeMultiplier = 1.17;

box off
hold off

% save fig
% print(fig, '-dtiff', '-r1000', fullfile('final_plot', 'bar_sig_ab_zz_origVSshuff'));