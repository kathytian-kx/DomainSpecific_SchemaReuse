clear;clc

% compute number of orthgonal for multiple days
root = '../data/firing_rates';
contents = dir(root);
n_comps = 20;
n_shuffle = 10;
orthog_range = 5;
% removed = 'none';
orthogonal_statics = struct();

% get files only
files = {};
for i=1:length(contents)
    if contents(i).isdir == 0 
        files{end+1} = contents(i).name;
    end
end

for i=1:length(files)
    fname = files{i};
    fprintf("=== dataset %d: %s ===\n", i, fname);
    data = load(fullfile(root, fname));
    
    [idx_stim, idx_motion, W, explVar, angle_matrix] = angle_statics(data, n_comps);
    
    orthogonal_cnt = sum(angle_matrix > 90-orthog_range & angle_matrix < 90+orthog_range, 'all');
    orthogonal_prob = orthogonal_cnt / (length(idx_stim) * length(idx_motion));

    % assign to orthogonal_statics
    orthogonal_statics(i).name = fname;
    orthogonal_statics(i).stimulus = idx_stim;
    orthogonal_statics(i).motion = idx_motion;
    orthogonal_statics(i).W = W;
    orthogonal_statics(i).stim_explVar = explVar.componentVar(idx_stim);
    orthogonal_statics(i).motion_explVar = explVar.componentVar(idx_motion);
    orthogonal_statics(i).angle_matrix = angle_matrix;
    orthogonal_statics(i).orthogonal_prob = orthogonal_prob;
    
    % shuffle
    orthogonal_statics(i).orthogonal_prob_shuff = zeros(1, n_shuffle);
    orthogonal_statics(i).angle_matrix_shuff = cell(1, n_shuffle);
    orthogonal_statics(i).stimulus_shuff = cell(1, n_shuffle);
    orthogonal_statics(i).motion_shuff = cell(1, n_shuffle);
    orthogonal_statics(i).W_shuff = cell(1, n_shuffle);
    for j=1:n_shuffle
        fprintf("--- dataset %s, shuffle %d ---\n", fname, j);
        data_shuff = data;
        data_shuff.condition_rw = data.condition_rw(randperm(length(data.condition_rw)));
        data_shuff.conditions_played = data.conditions_played(randperm(length(data.conditions_played)));
        try
            [idx_stim_shuff, idx_motion_shuff, W_shuff, ~, angle_matrix_shuff] = angle_statics(data_shuff, n_comps);
        catch exception
            disp(exception);
            fprintf('Skip this shuffle...');
            j = j - 1;
            continue
        end
        orthogonal_cnt_shuff = sum(angle_matrix_shuff > 90-orthog_range & angle_matrix_shuff < 90+orthog_range, 'all');
        orthogonal_prob_shuff = orthogonal_cnt_shuff / (length(idx_stim_shuff) * length(idx_motion_shuff));
        orthogonal_statics(i).orthogonal_prob_shuff(j) = orthogonal_prob_shuff;
        orthogonal_statics(i).angle_matrix_shuff{j} = angle_matrix_shuff;
        orthogonal_statics(i).stimulus_shuff{j} = idx_stim_shuff;
        orthogonal_statics(i).motion_shuff{j} = idx_motion_shuff;
        orthogonal_statics(i).W_shuff{j} = W_shuff;
    end
    
end

% save statics
disp("done!");
sname = sprintf('orthogonal_statics');
save(sname, 'orthogonal_statics');

