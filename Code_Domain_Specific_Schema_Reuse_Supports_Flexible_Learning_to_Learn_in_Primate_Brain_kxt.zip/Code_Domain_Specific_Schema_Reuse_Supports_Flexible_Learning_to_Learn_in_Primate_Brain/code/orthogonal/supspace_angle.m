orth_statics_name = 'orthogonal_statics.mat'; 
load(orth_statics_name);
n_days = length(orthogonal_statics);
n_shuff = length(orthogonal_statics(1).orthogonal_prob_shuff);

%% compute angle between subspace 
ang_subspace = zeros(n_days, 1);
stim_dim = 3;
for i=1:n_days
    W = orthogonal_statics(i).W;
    W_stim = W(:, orthogonal_statics(i).stimulus);
    W_motion = W(:, orthogonal_statics(i).motion);
    ang_subspace(i) = subspace(W_stim(:, 1:stim_dim), W_motion) / pi * 180;
    orthogonal_statics(i).subspace_angle = ang_subspace(i);
end

orth_num = sum(ang_subspace > 80 & ang_subspace < 100, 'all');
orth_ratio = orth_num / n_days;

%% compute angle between subspace after shuffle
ang_shuff_subspace = zeros(n_days, n_shuff);
stim_dim = 3;
for i=1:n_days
    for j=1:n_shuff
        W = orthogonal_statics(i).W_shuff{j};
        if isempty(W)
            ang_shuff_subspace(i, j) = -1;
        else
            W_stim = W(:, orthogonal_statics(i).stimulus_shuff{j});
            W_motion = W(:, orthogonal_statics(i).motion_shuff{j});
            ang_shuff_subspace(i, j) = subspace(W_stim(:, 1:stim_dim), W_motion) / pi * 180;
        end
    end
    orthogonal_statics(i).ang_shuff_subspace = ang_shuff_subspace(i, :);
end

efficient_num = sum(ang_shuff_subspace ~= -1, 'all');
orth_num = sum(ang_shuff_subspace > 80 & ang_shuff_subspace < 100, 'all');
orth_ratio_shuff = orth_num / efficient_num;

save(orth_statics_name, 'orthogonal_statics');
